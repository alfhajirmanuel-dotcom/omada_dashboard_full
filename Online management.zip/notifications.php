<?php
include 'config.php';
session_start();
include 'accept_reject_volunteer.php';
// Display notifications
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? AND is_read = FALSE");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    echo $row['notification_message'] . "<br>";
    // Mark notification as read
    $stmt = $conn->prepare("UPDATE notifications SET is_read = TRUE WHERE id = ?");
    $stmt->bind_param("i", $row['id']);
    $stmt->execute();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notification System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="notification-container">
        <h2>Notifications</h2>
        <ul id="notification-list">
            <!-- notifications will be displayed here -->
        </ul>
    </div>

    <script src="script.js"></script>
</body>
</html>

<style>
.notification-container {
    width: 300px;
    background-color: #f0f0f0;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#notification-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.notification-item {
    padding: 10px;
    border-bottom: 1px solid #ccc;
}

.notification-item:last-child {
    border-bottom: none;
}

.notification-message {
    font-size: 16px;
    font-weight: bold;
}

.notification-date {
    font-size: 14px;
    color: #666;
}

.read {
    background-color: #f0f0f0;
}

.unread {
    background-color: #fff;
}

</style>
<script>
// script.js
fetch('notifications.php')
    .then(response => response.json())
    .then(data => {
        const notificationList = document.getElementById('notification-list');
        data.forEach(notification => {
            const notificationItem = document.createElement('li');
            notificationItem.classList.add('notification-item');
            if (notification.is_read === '0') {
                notificationItem.classList.add('unread');
            } else {
                notificationItem.classList.add('read');
            }
            if (notification.type === 'new_application') {
                notificationItem.innerHTML = `
                    <span class="notification-message">${notification.notification_message}</span>
                    <span class="notification-date">${notification.notification_date}</span>
                    <button class="view-application" data-event-id="${notification.event_id}">View Application</button>
                `;
            } else {
                notificationItem.innerHTML = `
                    <span class="notification-message">${notification.notification_message}</span>
                    <span class="notification-date">${notification.notification_date}</span>
                `;
            }
            notificationList.appendChild(notificationItem);
        });

        // Add event listener for view application button
        const viewApplicationButtons = document.querySelectorAll('.view-application');
        viewApplicationButtons.forEach(button => {
            button.addEventListener('click', event => {
                const eventId = event.target.dataset.eventId;
                console.log(eventId); // Check if eventId is logged correctly
                // Fetch application details
                fetch(`view_application.php?event_id=${eventId}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log(data); // Check if data is fetched correctly
                        // Display application details
                        const applicationDetails = document.createElement('div');
                        applicationDetails.innerHTML = `
                            <h2>Application Details</h2>
                            <p>Full Name: ${data.full_name}</p>
                            <p>Email: ${data.email}</p>
                            <p>Contact Number: ${data.contact_number}</p>
                            <p>Age: ${data.age}</p>
                            <p>Gender: ${data.gender}</p>
                            <p>Address: ${data.address}</p>
                        `;
                        document.body.appendChild(applicationDetails);
                    })
                    .catch(error => console.error('Error fetching application details:', error));
            });
        });
    })
    .catch(error => console.error('Error fetching notifications:', error));

// notifications.php
$stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ?");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$notifications = array();
while ($row = $result->fetch_assoc()) {
    $notifications[] = array(
        'id' => $row['id'],
        'notification_message' => $row['notification_message'],
        'notification_date' => $row['notification_date'],
        'is_read' => $row['is_read'],
        'type' => $row['notification_type'],
        'event_id' => $row['event_id'] // Add this line
    );
}
echo json_encode($notifications);

</script>
