<?php
include 'config.php';

if (isset($_GET['event_id'])) {
    $eventId = $_GET['event_id'];

    // Get application details from volunteer_applications table
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE event_id = ?");
    $stmt->bind_param("i", $eventId);
    $stmt->execute();
    $result = $stmt->get_result();
    $application = $result->fetch_assoc();

    if ($application) {
        header('Content-Type: application/json');
        echo json_encode($application);
    } else {
        header('Content-Type: application/json');
        echo json_encode(array('error' => 'No application found'));
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(array('error' => 'Event ID not provided'));
}
exit;
?>
