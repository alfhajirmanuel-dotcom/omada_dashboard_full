<?php

include 'config.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
}
$stmt = $conn->prepare("SELECT events.*, users.username FROM events JOIN users ON events.user_id = users.id ORDER BY events.id DESC");
$stmt->execute();
$result = $stmt->get_result();
$events = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Events</h2>
        <ul class="event-list">
            <?php foreach ($events as $event): ?>
            <li>
                <h3><?php echo $event['title']; ?></h3>
                <p><?php echo $event['description']; ?></p>
                <p>Date: <?php echo $event['date']; ?></p>
                <p>Time: <?php echo $event['time']; ?></p>
                <?php if (file_exists('uploads/' . $event['image'])): ?>
                <img src="uploads/<?php echo $event['image']; ?>" alt="Event Image">
                <?php else: ?>
                <p>Image not found.</p>
                <?php endif; ?>
                <p class="posted-by">Posted by: <?php echo $event['username']; ?></p>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>

<style>

.event-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.event-list li {
    background-color: #f9f9f9;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}

.event-list h3 {
    margin-top: 0;
}

.event-list img {
    max-width: 100%;
    height: auto;
    border-radius: 10px;
    margin: 10px 0;
}

.posted-by {
    font-size: 14px;
    color: #666;
}
</style>