<?php
session_start();
include 'config.php';
include 'header.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Base query
$sql = "SELECT id, title, description, date FROM events";
$conditions = [];

if ($filter === 'new') {
    $conditions[] = "date >= CURDATE() - INTERVAL 7 DAY";
} elseif ($filter === 'upcoming') {
    $conditions[] = "date >= CURDATE()";
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}

$sql .= " ORDER BY date DESC";

$result = $conn->query($sql);
?>

<style>
body {
  font-family: 'Poppins', sans-serif;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  color: #fff;
  margin: 0;
  padding: 0;
}

/* Container */
.event-list-container {
  width: 95%;
  max-width: 900px;
  margin: 40px auto;
  background: rgba(255, 255, 255, 0.08);
  border-radius: 14px;
  padding: 25px;
  backdrop-filter: blur(12px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
}

/* Header */
.event-list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}
.event-list-header h2 {
  color: #00e5ff;
  font-size: 24px;
  margin-bottom: 10px;
}
.topbar{
 background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
 color: #0591f7;
}
/* Filter Links */
.filter-links a {
  color: #00e5ff;
  text-decoration: none;
  font-weight: 500;
  margin-right: 12px;
}
.filter-links a.active {
  color: #fff;
  border-bottom: 2px solid #00e5ff;
  padding-bottom: 2px;
}
.filter-links a:hover {
  text-decoration: underline;
}

/* Table */
.table-wrapper {
  margin-top: 20px;
  overflow-x: auto;
  max-height: 400px;
  overflow-y: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
  background: rgba(255,255,255,0.05);
  border-radius: 8px;
  overflow: hidden;
}
thead {
  background: rgba(255,255,255,0.12);
}
th, td {
  padding: 12px 15px;
  text-align: left;
  color: #eee;
  font-size: 14px;
}
th {
  color: #00e5ff;
  font-weight: 600;
}
tbody tr:nth-child(even) {
  background: rgba(255,255,255,0.05);
}
tbody tr:hover {
  background: rgba(0,229,255,0.15);
  transition: 0.3s;
}

/* No Events */
.no-events {
  text-align: center;
  padding: 25px;
  color: #ccc;
  font-size: 15px;
}

/* Back Button */
.back-btn {
  display: inline-block;
  margin-top: 20px;
  background: linear-gradient(90deg, #00e5ff, #007bff);
  color: #fff;
  padding: 10px 18px;
  border-radius: 10px;
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}
.back-btn:hover {
  background: linear-gradient(90deg, #007bff, #00e5ff);
  transform: scale(1.03);
}

/* Responsive */
@media (max-width: 600px) {
  .event-list-header h2 {
    font-size: 20px;
  }
  th, td {
    font-size: 13px;
  }
}

.view-btn {
  display: inline-block;
  background: linear-gradient(90deg, #00e5ff, #007bff);
  color: #fff;
  padding: 6px 12px;
  border-radius: 8px;
  text-decoration: none;
  font-size: 13px;
  font-weight: 500;
  transition: 0.3s ease;
}

.view-btn:hover {
  background: linear-gradient(90deg, #007bff, #00e5ff);
  transform: scale(1.05);
}

</style>

<div class="event-list-container">
  <div class="event-list-header">
    <h2>
      <?php
        if ($filter === 'new') echo "🆕 New Events (Last 7 Days)";
        elseif ($filter === 'upcoming') echo "📅 Upcoming Events";
        else echo "📋 All Events";
      ?>
    </h2>

    <div class="filter-links">
      <a href="?filter=all" class="<?= $filter==='all'?'active':'' ?>">All</a>
      <a href="?filter=new" class="<?= $filter==='new'?'active':'' ?>">New</a>
      <a href="?filter=upcoming" class="<?= $filter==='upcoming'?'active':'' ?>">Upcoming</a>
    </div>
  </div>

 <div class="table-wrapper">
  <?php if ($result && $result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Event Title</th>
          <th>Description</th>
          <th>Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['title']) ?></td>
            <td><?= htmlspecialchars(strlen($row['description']) > 60 ? substr($row['description'], 0, 60) . '...' : $row['description']) ?></td>
            <td><?= htmlspecialchars($row['date']) ?></td>
            <td>
              <a href="event_view.php?id=<?= urlencode($row['id']) ?>" class="view-btn">View</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <div class="no-events">No events found.</div>
  <?php endif; ?>
</div>
