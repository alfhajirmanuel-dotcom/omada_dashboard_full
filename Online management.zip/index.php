<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Our Community</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
         <img src="loga.png" alt="Community Service hub" width="120" height="120">
        <h1> Welcome To CMS</h1>
       
        <nav>
            <ul>
                <li><a href="login.php" class="login-btn">Login</a></li>
                <li><a href="register.php" class="signup-btn">Sign Up</a></li>
                
        </nav>
    </header>
    <main>
        <section class="slideshow-container">
            <div class="slideshow">
                <img src="image1.jpg" alt="Image 1">
                <img src="image-2.png" alt="Image 2">
                <img src="image-3.jpg" alt="Image 3">
                <img src="image-4.jpg" alt="Image 4">
            </div>
            <div class="dot-container">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </section>
        
        <section class="encouragement">
            <h2>You Are Capable of Great Things</h2>
            <p>Believe in yourself and your abilities. You have the power to make a difference in the world.</p>
            <blockquote>"The best way to predict your future is to create it."</blockquote>
            <cite></cite>
        </section>
        <section class="call-to-action">
            
            <h2>Take the First Step</h2>
            <p>Join our community today and start making a difference.</p>
            <a href="register.php" class="cta-btn">Sign Up Now</a>
        </section>
    </main>
    <footer>
        <p style="text-align:center;">&copy; 2025 Our Community</p>
    </footer>
    <script src="script.js"></script>
</body>
</html>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

header {
    background-color: #3E8C6D;
    color: #fff;
    padding: 20px;
    text-align: center;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
}

header nav ul li {
    margin-right: 20px;
}

.login-btn {
    background-color: #fff;
    color: #4CAF50;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    text-decoration: none;
    margin: auto;

}

.signup-btn {
    background-color: #3e8e41;
    color: #fff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    text-decoration: none;
    margin: auto;
   
}

.slideshow-container {
    position: relative;
    width: 100%;
    height: 500px;
}

.slideshow {
    position: relative;
    width: 100%;
    height: 100%;
}

.slideshow img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: none;
}

.slideshow img.active {
    display: block;
}

.dot-container {
    position: absolute;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
}

.dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: #fff;
    margin-right: 10px;
    cursor: pointer;
}

.dot.active {
    background-color: #4CAF50;
}

.encouragement {
    padding: 20px;
    text-align: center;
}

.encouragement blockquote {
    font-size: 24px;
    font-style: italic;
    margin-bottom: 10px;
}

.call-to-action {
    background-color: #4CAF50;
    color: #fff;
    padding: 20px;
    text-align: center;
}

.cta {
    background-color: #fff;
    color: #4CAF50;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    cursor: pointer;
    text-decoration: none;
}

footer {
    background-color: #fff;
    color: #fff
footer {
    background-color: #fff;
    color: #fff;
    padding: 10px;
    text-align: center;
    clear: both;
}
</style>
<script>

let slideIndex = 0;
let slides = document.querySelectorAll('.slideshow img');
let dots = document.querySelectorAll('.dot');

function showSlides() {
    for (let i = 0; i < slides.length; i++) {
        slides[i].classList.remove('active');
        dots[i].classList.remove('active');
    }
    slides[slideIndex].classList.add('active');
    dots[slideIndex].classList.add('active');
}

function nextSlide() {
    slideIndex++;
    if (slideIndex >= slides.length) {
        slideIndex = 0;
    }
    showSlides();
}

function prevSlide() {
    slideIndex--;
    if (slideIndex < 0) {
        slideIndex = slides.length - 1;
    }
    showSlides();
}

function currentSlide(n) {
    slideIndex = n;
    showSlides();
}

showSlides();
setInterval(nextSlide, 5000);

dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
        currentSlide(index);
    });
});

</script>