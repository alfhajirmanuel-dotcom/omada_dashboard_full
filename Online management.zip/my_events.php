<?php
session_start();
include 'config.php';
include 'header.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$user_id = $user['id'];

// Get events posted by the user
$stmt = $conn->prepare("SELECT * FROM events WHERE user_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$my_events = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Events</title>
<style>
    body {
        font-family: "Segoe UI", Arial, sans-serif;
         background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
        margin: 0;
        padding: 0;
    }

    .dashboard-container {
        display: flex;
    }

    .topbar {
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    color: #0591f7;
}
    
    .main-content {
        margin-left: 240px;
        padding: 30px;
        width: calc(100% - 240px);
        transition: 0.3s;
    }


    .card-container {
        max-width: 1000px;
        margin: 0 auto;
         max-height: 70vh; /* Adjust height depending on how much you want visible */
  overflow-y: auto;
  padding-right: 8px; /* space for scrollbar */
    }
    html, body {
  height: 107%;
  margin: 0;
  font-family: "Poppins", "Segoe UI", Inter, Roboto, Arial, sans-serif;
   background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  color: #222;
}
    .event-card {
        background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.08);
        padding: 20px;
        margin-bottom: 20px;
        transition: 0.3s;
    }

    .event-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 14px rgba(0,0,0,0.1);
    }

    .event-card h3 {
        margin-top: 0;
        color: #fff;
    }

    .event-card p {
        margin: 5px 0;
        color: #fff;
    }

    .event-card img {
        width: 100%;
        height: 400px;
        object-fit: cover;
        border-radius: 10px;
        margin: 20px 0;
        
    }

    .event-card .btn {
        display: inline-block;
        margin-top: 8px;
        padding: 8px 14px;
        font-size: 14px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        text-decoration: none;
    }

    .edit-btn { background-color: #3b82f6; color: white; }
    .delete-btn { background-color: #ef4444; color: white; }
    .accept-btn { background-color: #10b981; color: white; }
    .reject-btn { background-color: #ef4444; color: white; }

    .event-card ul {
        list-style: none;
        padding-left: 0;
    }

    .event-card ul li {
        background: #f9fafb;
        border-radius: 6px;
        padding: 6px 10px;
        margin-bottom: 5px;
    }

    h2.page-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: #0591f7;
        margin-bottom: 20px;
    }

    /* RESPONSIVE STYLES */
    @media (max-width: 1024px) {
        .main-content {
            margin-left: 220px;
            width: calc(100% - 220px);
        }
    }

   
        .main-content {
            margin-left: 0;
            width: 100%;
            padding: 20px;
        }

     
       
    }

    @media (max-width: 480px) {
        .event-card {
            padding: 15px;
        }

        .btn {
            padding: 6px 10px;
            font-size: 12px;
        }

        .page-title {
            font-size: 1.2rem;
        
        }

        
</style>
</head>
<body>



    <div class="main-content">
        <h2 class="page-title">My Events</h2>
        <div class="card-container">
            <?php foreach ($my_events as $event): ?>
                <div class="event-card">
                    <h3><?php echo $event['title']; ?></h3>
                    <p><?php echo $event['description']; ?></p>
                    <p><strong>Date:</strong> <?php echo $event['date']; ?> | <strong>Time:</strong> <?php echo $event['time']; ?></p>
                    <?php if (file_exists('uploads/' . $event['image'])): ?>
                        <img src="uploads/<?php echo $event['image']; ?>" alt="Event Image">
                    <?php else: ?>
                        <p>Image not found.</p>
                    <?php endif; ?>

                    
                    <?php
                    $stmt = $conn->prepare("SELECT volunteers.*, users.full_name FROM volunteers JOIN users ON volunteers.user_id = users.id WHERE volunteers.event_id = ?");
                    $stmt->bind_param("i", $event['id']);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $volunteers = $result->fetch_all(MYSQLI_ASSOC);
                    ?>
                    <ul hidden >
                        <?php foreach ($volunteers as $volunteer): ?>
                            <li>
                                
                                <?php if ($volunteer['status'] == 'pending'): ?>
                                    <a hidden href="update_volunteer.php?volunteer_id=<?php echo $volunteer['id']; ?>&event_id=<?php echo $event['id']; ?>&action=accept" class="btn accept-btn">Accept</a>
                                    <a hidden href="update_volunteer.php?volunteer_id=<?php echo $volunteer['id']; ?>&event_id=<?php echo $event['id']; ?>&action=reject" class="btn reject-btn">Reject</a>
                                <?php elseif ($volunteer['status'] == 'accepted'): ?>
                                    <span hidden style="color: green;">Accepted</span>
                                <?php elseif ($volunteer['status'] == 'rejected'): ?>
                                    <span hidden style="color: red;">Rejected</span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <a href="edit_event.php?event_id=<?php echo $event['id']; ?>" class="btn edit-btn">Edit</a>
                    <a href="delete_event.php?event_id=<?php echo $event['id']; ?>" class="btn delete-btn">Delete</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('active');
}
</script>

</body>
</html>
