<?php 
include 'config.php'; 
include 'header.php';
$stmt = $conn->prepare("SELECT full_name, gender, profile_picture FROM users WHERE username = ?");
$stmt->bind_param("s", $_GET['username']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
  ?>
  <style>
    .profile-container {
      width: 80%;
      margin: 40px auto;
      padding: 20px;
      background-color: #fff;
      border: 1px solid #ddd;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .profile-picture {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      margin: 20px auto;
    }
  </style>
  <div class="profile-container">
    <?php if (!empty($user['profile_picture'])): ?>
      <img src="uploads/<?php echo $user['profile_picture']; ?>" alt="Profile Picture" class="profile-picture">
    <?php else: ?>
      <img src="default-profile-picture.jpg" alt="Default Profile Picture" class="profile-picture">
    <?php endif; ?>
    <h2><?php echo $user['full_name']; ?></h2>
    <p>Gender: <?php echo $user['gender']; ?></p>
  </div>
  <?php
} else {
  echo "User not found.";
}
?>