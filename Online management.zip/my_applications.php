<?php
include 'config.php';
include 'header.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Fetch current user
$stmt = $conn->prepare("SELECT id, profile_picture FROM users WHERE username = ?");
$stmt->bind_param("s", $_SESSION['username']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$user_id = $user['id'];

// ✅ Delete Application
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM volunteers WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $delete_id, $user_id);
    if ($stmt->execute()) {
        echo "<script>
            alert('⚠️ Application deleted successfully!');
            window.location.href='my_applications.php';
        </script>";
        exit;
    } else {
        echo "<script>
            alert('❌ Failed to delete application.');
            window.location.href='my_applications.php';
        </script>";
        exit;
    }
}

// ✅ Update Application Status
if (isset($_POST['update_status'])) {
    $app_id = intval($_POST['app_id']);
    $new_status = $_POST['status'];
    $comment = $_POST['comment'] ?? '';

    $stmt = $conn->prepare("
        UPDATE volunteer_applications 
        SET status = ?, comment = ? 
        WHERE user_id = ? AND event_id = (SELECT event_id FROM volunteers WHERE id = ?)
    ");
    $stmt->bind_param("ssii", $new_status, $comment, $user_id, $app_id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Application updated successfully.";
    } else {
        $_SESSION['error'] = "Failed to update application.";
    }

    // ✅ Redirect to same page to refresh
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ✅ Fetch all volunteer applications
$stmt = $conn->prepare("
    SELECT v.*, e.title AS event_title, e.date, e.time,
           va.status AS application_status, va.comment AS admin_comment
    FROM volunteers v
    JOIN events e ON v.event_id = e.id
    LEFT JOIN volunteer_applications va 
        ON va.event_id = e.id AND va.user_id = v.user_id
    WHERE v.user_id = ?
    ORDER BY v.id DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$applications = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Volunteer Applications</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<style>
:root {
  --accent: #00aaff;
  --radius: 12px;
}
body {
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  color: #fff;
  font-family: "Poppins", sans-serif;
}
.panel {
  background: rgba(255,255,255,0.05);
  border-radius: var(--radius);
  padding: 20px;
  box-shadow: 0 4px 18px rgba(0,0,0,0.3);
}
.app-card {
  background: #2d2a42;
  border-radius: var(--radius);
  padding: 16px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.25);
  transition: all 0.2s ease;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.app-card:hover {
  transform: translateY(-3px);
}
.app-title {
  font-size: 18px;
  font-weight: 600;
  color: #00aaff;
}
.status {
  font-weight: 600;
  padding: 6px 12px;
  border-radius: 10px;
}
.status.pending { background: #c1940a33; color: #ffd64f; }
.status.accepted { background: #0a6b1b33; color: #05f75e; }
.status.rejected { background: #5a0a0a33; color: #f55; }
.btn-edit {
  background: linear-gradient(90deg, #007bff, #00c6ff);
  border: none;
  padding: 6px 12px;
  color: #fff;
  border-radius: var(--radius);
  transition: all 0.2s ease;
  text-align: center;
}
.btn-edit:hover {
  background: linear-gradient(90deg, #0056b3, #00a6ff);
}
.status-comment {
  border-radius: 10px;
  padding: 10px;
  margin-top: 10px;
  font-size: 14px;
  font-weight: 500;
}
.comment-pending { background: rgba(255, 215, 0, 0.15); color: #ffd64f; }
.comment-accepted { background: rgba(0, 255, 100, 0.15); color: #05f75e; }
.comment-rejected { background: rgba(255, 50, 50, 0.15); color: #ff6b6b; }
.alert {
  border-radius: var(--radius);
  padding: 12px 18px;
  font-weight: 500;
}
.alert-warning {
  background-color: #ffb84d;
  color: #4a2c00;
  border: none;
}

.topbar {
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    color: #0591f7;
}
</style>
</head>
<body>

<div class="container mt-5">
  <h2 class="mb-4">🧾 My Volunteer Applications</h2>

  <!-- ✅ Display Messages -->
  <?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success text-center"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
  <?php elseif (isset($_SESSION['warning'])): ?>
    <div class="alert alert-warning text-center"><?php echo $_SESSION['warning']; unset($_SESSION['warning']); ?></div>
  <?php elseif (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger text-center"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
  <?php endif; ?>

  <?php if (count($applications) > 0): ?>
    <div class="row">
      <?php foreach ($applications as $app): ?>
        <?php 
          $status = !empty($app['application_status']) ? $app['application_status'] : $app['status'];
          $commentClass = 'comment-pending';
          if (strtolower($status) == 'accepted') $commentClass = 'comment-accepted';
          elseif (strtolower($status) == 'rejected') $commentClass = 'comment-rejected';
        ?>
        <div class="col-md-4 mb-4">
          <div class="app-card">
            <div>
              <div class="app-title"><?php echo htmlspecialchars($app['event_title']); ?></div>
              <p>Date: <?php echo htmlspecialchars($app['date']); ?> | Time: <?php echo htmlspecialchars($app['time']); ?></p>
              <p>Status: 
                <span class="status <?php echo strtolower($status); ?>">
                  <?php echo ucfirst($status); ?>
                </span>
              </p>

              <?php if (!empty($app['admin_comment'])): ?>
                <div class="status-comment <?php echo $commentClass; ?>">
                  <strong>Admin Comment:</strong> 
                  <?php echo nl2br(htmlspecialchars($app['admin_comment'])); ?>
                </div>
              <?php endif; ?>
            </div>

            <div class="mt-3 d-flex justify-content-between">
              <a hidden href="edit_application.php?id=<?php echo $app['id']; ?>" class="btn-edit">Edit / View</a>
              <a href="my_applications.php?delete_id=<?php echo $app['id']; ?>" 
                 class="btn btn-danger btn-sm" 
                 onclick="return confirm('⚠️ Are you sure you want to delete this application? This action cannot be undone.');">
                 Delete
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="panel text-center">
      <p>You haven’t applied to any events yet.</p>
    </div>
  <?php endif; ?>
</div>

</body>
</html>
