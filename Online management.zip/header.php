<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    include 'header.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- Font Awesome CDN for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: "Segoe UI", sans-serif; }

        body {
            display: flex;
            height: 100vh;
            background: #f5f7fa;
        }

        /* Sidebar */
        .sidebar {
            width: 230px;
            background: #0b3d91;
            color: white;
            display: flex;
            flex-direction: column;
            padding-top: 20px;
            transition: transform 0.3s ease;
        }

        .sidebar h2 {
            text-align: center;
            font-size: 20px;
            margin-bottom: 20px;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            transition: 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #1b5bd7;
        }

        /* Topbar */
        .topbar {
            width: 100%;
            background: #ffffff;
            padding: 12px 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            
        }

        .topbar h1 {
            font-size: 18px;
            color:#0591f7;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .menu-toggle {
            display: none;
            font-size: 20px;
            background: none;
            border: none;
            color: #0b3d91;
            cursor: pointer;
        }

        .user-info {
            font-size: 14px;
            color: #666;
        }

        /* Main Layout */
        .main {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .content {
            padding: 30px;
            flex: 1;
            overflow-y: auto;
        }

        /* Card Style */
        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
        }

        .card h2 {
            margin-bottom: 20px;
            color: #333;
        }

        /* Buttons */
        .btn {
            background: #007bff;
            color: white;
            padding: 8px 14px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
            transition: 0.3s;
        }

        .btn:hover {
            background: #0056b3;
        }

        .btn-danger {
            background: #e53935;
        }

        .btn-danger:hover {
            background: #c62828;
        }

        /* Overlay for mobile menu */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.4);
            z-index: 998;
        }

        /* Responsive View */
        @media (max-width: 768px) {
            body {
                flex-direction: column;
            }

            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                height: 100%;
                transform: translateX(-100%);
                z-index: 999;
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .menu-toggle {
                display: inline-block;
            }

            .overlay.active {
                display: block;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <h2>Dashboard</h2>
        <a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>">
            <i class="fa-solid fa-chart-line"></i> Dashboard
        </a>
        <a href="events.php" class="<?= basename($_SERVER['PHP_SELF'])=='events.php'?'active':'' ?>">
            <i class="fa-solid fa-calendar-plus"></i> Create Event
        </a>
        <a href="my_events.php" class="<?= basename($_SERVER['PHP_SELF'])=='my_events.php'?'active':'' ?>">
            <i class="fa-solid fa-calendar-check"></i> My Events
        </a>
        <a href="profile.php" class="<?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>">
            <i class="fa-solid fa-user"></i> Profile
        </a>
         <a href="settings.php" class="<?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>">
        <i class="fa-solid fa-gear"></i> Settings
    </a>
    </div>

    <!-- Overlay -->
    <div class="overlay" id="overlay"></div>

    <div class="main">
        <div class="topbar">
            <h1>
                <button class="menu-toggle" id="menuToggle">
                    <i class="fa-solid fa-bars"></i>
                </button>
                 Dashboard
            </h1>
            <div class="user-info">
                Logged in as: <strong><?= $_SESSION['username'] ?? 'Guest' ?></strong>
            </div>
        </div>

        

    <!-- JavaScript for Hamburger Toggle -->
    <script>
    const menuToggle = document.getElementById('menuToggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');

    menuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    });

    overlay.addEventListener('click', () => {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    });
    </script>
    <script>
    // fetch notifications from database
fetch('notifications.php')
    .then(response => response.json())
    .then(data => {
        const notificationList = document.getElementById('notification-list');
        data.forEach(notification => {
            const notificationItem = document.createElement('li');
            notificationItem.classList.add('notification-item');
            if (notification.is_read === '0') {
                notificationItem.classList.add('unread');
            } else {
                notificationItem.classList.add('read');
            }
            notificationItem.innerHTML = `
                <span class="notification-message">${notification.notification_message}</span>
                <span class="notification-date">${notification.notification_date}</span>
            `;
            notificationList.appendChild(notificationItem);
        });
    })
    .catch(error => console.error('Error fetching notifications:', error));

// mark notification as read
document.addEventListener('click', event => {
    if (event.target.classList.contains('notification-item')) {
        const notificationId = event.target.dataset.id;
        fetch(`mark_as_read.php?id=${notificationId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    event.target.classList.remove('unread');
                    event.target.classList.add('read');
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
    }
});


</script>


</body>
</html>
