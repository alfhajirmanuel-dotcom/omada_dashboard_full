<?php
session_start();
include 'config.php';

$error = '';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if ($password == $user['password']) {
                $_SESSION['username'] = $username;
                header("Location: dashboard.php");
            } else {
                $error = 'Invalid username or password';
            }
        } else {
            $error = 'Invalid username or password';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<style>
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 🌈 Login Box */
.login-container {
  width: 90%;
  max-width: 380px;
  background: rgba(255, 255, 255, 0.08);
  border-radius: 16px;
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
  padding: 40px 30px 35px;
  text-align: center;
  color: #fff;
  animation: fadeIn 0.6s ease;
}

/* 🪄 Animation */
@keyframes fadeIn {
  from {opacity: 0; transform: translateY(-15px);}
  to {opacity: 1; transform: translateY(0);}
}

/* 🧠 Heading */
h2 {
  font-size: 28px;
  font-weight: 600;
  margin-bottom: 20px;
  color: #00e5ff;
}

/* ⚠️ Error Box */
.error-message {
  background-color: rgba(255, 69, 58, 0.95);
  color: #fff;
  padding: 10px 15px;
  border-radius: 10px;
  margin: 0 auto 18px;
  display: inline-block;
  font-size: 14px;
  box-shadow: 0 0 8px rgba(255, 69, 58, 0.6);
}

/* 🧩 Input Groups */
.input-group {
  position: relative;
  margin-bottom: 22px;
  text-align: left;
}

.input-group label {
  display: block;
  font-size: 14px;
  margin-bottom: 5px;
  color: #eee;
}

.input-group input {
  width: 85%;
  padding: 10px 45px 10px 12px;
  border-radius: 10px;
  border: none;
  outline: none;
  font-size: 15px;
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
  transition: all 0.3s ease;
}

.input-group input:focus {
  background: rgba(255,255,255,0.25);
  box-shadow: 0 0 8px #00e5ff;
}

/* 👁️ Icons inside input */
.input-group i.fa-lock,
.input-group i.fa-user {
  position: absolute;
  right: 38px;
  top: 37px;
  color: #ccc;
  pointer-events: none;
}

.toggle-password {
  position: absolute;
  right: 10px;
  top: 37px;
  cursor: pointer;
  color: #ccc;
  transition: 0.3s;
}
.toggle-password:hover {
  color: #00e5ff;
}

/* 🚀 Login Button */
button[type="submit"] {
  width: 100%;
  padding: 12px;
  border: none;
  background: linear-gradient(90deg, #00e5ff, #007bff);
  color: #fff;
  font-size: 16px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 500;
  transition: 0.3s;
  box-shadow: 0 0 12px rgba(0, 229, 255, 0.4);
}

button[type="submit"]:hover {
  background: linear-gradient(90deg, #007bff, #00e5ff);
  transform: scale(1.03);
  box-shadow: 0 0 15px rgba(0, 229, 255, 0.6);
}

/* 🔗 Links */
.login-container p {
  margin-top: 16px;
  font-size: 14px;
}
.login-container p a {
  color: #00e5ff;
  text-decoration: none;
  font-weight: 500;
}
.login-container p a:hover {
  text-decoration: underline;
}

/* 📱 Responsive */
@media (max-width: 480px) {
  .login-container {
    padding: 30px 20px;
  }
  h2 {
    font-size: 22px;
  }
  .error-message {
    font-size: 13px;
  }
}
</style>

</head>
<body>

<div class="login-container">
  <form action="" method="post">
    <h2>Login</h2>
    <?php if (!empty($error)) : ?>
      <div class="error-message"><?= $error; ?></div>
    <?php endif; ?>
    
    <div class="input-group">
      <label for="username">Username</label>
      <input type="text" id="username" name="username" required autocomplete="username">
      <i class="fa-solid fa-user"></i>
    </div>
    
    <div class="input-group">
  <label for="password">Password</label>
  <input type="password" id="password" name="password" required autocomplete="current-password">
  <i class="fa-solid fa-lock"></i>
  <span class="toggle-password" onclick="togglePasswordVisibility()">
    <i class="fa-solid fa-eye"></i>
  </span>
</div>

    
    <button type="submit" name="login">Login</button>
    
    <p>Don't have an account? <a href="register.php">Register</a></p>
    <p><a href="forgot-password.php">Forgot Password?</a></p>
  </form>
</div>

<script>
function togglePasswordVisibility() {
  const passwordInput = document.getElementById('password');
  const togglePasswordIcon = document.querySelector('.toggle-password i');
  if (passwordInput.type === 'password') {
      passwordInput.type = 'text';
      togglePasswordIcon.classList.replace('fa-eye', 'fa-eye-slash');
  } else {
      passwordInput.type = 'password';
      togglePasswordIcon.classList.replace('fa-eye-slash', 'fa-eye');
  }
}
</script>

</body>
</html>
