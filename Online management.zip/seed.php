<?php
include 'config.php';

$admin_password = password_hash('adminpassword', PASSWORD_DEFAULT);
$user1_password = password_hash('user1password', PASSWORD_DEFAULT);
$user2_password = password_hash('user2password', PASSWORD_DEFAULT);

$query = "INSERT INTO users (username, password, role) VALUES 
('admin', '$admin_password', 'admin'), 
('user1', '$user1_password', 'user'), 
('user2', '$user2_password', 'user')";
$result = $conn->query($query);

$query = "INSERT INTO events (title, description, date, time) VALUES 
('Community Clean-up', 'Join us for a community clean-up event!', '2024-09-20', '09:00:00'), 
('Charity Run', 'Participate in our charity run and help raise funds for a good cause!', '2024-10-15', '07:00:00')";
$result = $conn->query($query);

$query = "INSERT INTO posts (user_id, content) VALUES 
(1, 'Hello everyone! I\'m excited to share this post with you all.'), 
(2, 'I\'m looking forward to the community clean-up event this weekend!')";
$result = $conn->query($query);

$query = "INSERT INTO comments (post_id, user_id, content) VALUES 
(1, 2, 'Great post! I\'m excited to see what you have to share.'), 
(1, 3, 'I completely agree!')";
$result = $conn->query($query);
?>
