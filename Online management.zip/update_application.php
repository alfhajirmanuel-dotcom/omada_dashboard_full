<?php
session_start();
include 'config.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

if (isset($_POST['volunteer_id'])) {
  $volunteer_id = $_POST['volunteer_id'];
  $full_name = $_POST['full_name'];
  $contact_number = $_POST['contact_number'];
  $user_id = $_SESSION['user_id'];

  $upload_path = null;
  if (!empty($_FILES['id_upload']['name'])) {
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) {
      mkdir($target_dir, 0777, true);
    }
    $upload_name = time() . "_" . basename($_FILES["id_upload"]["name"]);
    $target_file = $target_dir . $upload_name;
    move_uploaded_file($_FILES["id_upload"]["tmp_name"], $target_file);
    $upload_path = $target_file;
  }

  if ($upload_path) {
    $stmt = $conn->prepare("UPDATE volunteers SET full_name=?, contact_number=?, id_upload=? WHERE id=? AND user_id=?");
    $stmt->bind_param("sssii", $full_name, $contact_number, $upload_path, $volunteer_id, $user_id);
  } else {
    $stmt = $conn->prepare("UPDATE volunteers SET full_name=?, contact_number=? WHERE id=? AND user_id=?");
    $stmt->bind_param("ssii", $full_name, $contact_number, $volunteer_id, $user_id);
  }

  $stmt->execute();
}

header("Location: my_applications.php");
exit;
