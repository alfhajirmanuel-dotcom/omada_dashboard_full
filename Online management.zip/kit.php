<?php
session_start();
include 'config';
include 'header.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Omada-Style Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: "Segoe UI", sans-serif;
    }

    body {
      background-color: #f5f6fa;
      color: #2f3640;
      overflow-x: hidden;
    }

    /* Sidebar */
    .sidebar {
      width: 240px;
      background-color: #1e272e;
      color: #fff;
      height: 100vh;
      position: fixed;
      top: 0;
      left: 0;
      display: flex;
      flex-direction: column;
      padding: 20px;
      transition: width 0.3s;
    }

    .sidebar h2 {
      font-size: 22px;
      font-weight: bold;
      text-align: center;
      margin-bottom: 40px;
      color: #00a8ff;
    }

    .sidebar a {
      color: #dcdde1;
      text-decoration: none;
      padding: 12px 15px;
      border-radius: 6px;
      margin: 4px 0;
      display: flex;
      align-items: center;
      transition: background 0.3s;
    }

    .sidebar a i {
      margin-right: 10px;
    }

    .sidebar a:hover, .sidebar a.active {
      background-color: #007cba;
      color: #fff;
    }

    /* Main Content */
    .main {
      margin-left: 240px;
      padding: 30px;
      transition: margin-left 0.3s;
    }

    .topbar {
      background-color: #fff;
      border-radius: 8px;
      padding: 15px 25px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 25px;
    }

    .topbar h1 {
      font-size: 20px;
      color: #2f3640;
    }

    .user-info {
      font-size: 14px;
      color: #555;
    }

    /* Cards */
    .cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .card {
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 1px 4px rgba(0,0,0,0.1);
      text-align: center;
      transition: transform 0.2s;
    }

    .card:hover {
      transform: translateY(-3px);
    }

    .card h3 {
      color: #007cba;
      font-size: 16px;
      margin-bottom: 8px;
    }

    .card p {
      font-size: 26px;
      font-weight: bold;
      color: #1e272e;
    }

    /* Charts */
    .charts {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 25px;
    }

    .chart-card {
      background: #fff;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 1px 4px rgba(0,0,0,0.1);
    }

    .footer {
      text-align: center;
      color: #999;
      margin-top: 40px;
      font-size: 14px;
    }

    @media (max-width: 768px) {
      .sidebar {
        width: 70px;
      }
      .sidebar h2, .sidebar a span {
        display: none;
      }
      .main {
        margin-left: 70px;
      }
      .charts {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <div class="sidebar">
    <h2>Omada Panel</h2>
    <a href="#" class="active"><i class="fas fa-home"></i><span>Dashboard</span></a>
    <a href="#"><i class="fas fa-ticket-alt"></i><span>Vouchers</span></a>
    <a href="#"><i class="fas fa-wifi"></i><span>SSIDs</span></a>
    <a href="#"><i class="fas fa-chart-line"></i><span>Analytics</span></a>
    <a href="#"><i class="fas fa-cog"></i><span>Settings</span></a>
    <a href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
  </div>

  <div class="main">
    <div class="topbar">
      <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> 👋</h1>
      <div class="user-info">Omada Dashboard Replica</div>
    </div>

    <!-- Summary Cards -->
    <div class="cards">
      <div class="card">
        <h3>Active Clients</h3>
        <p>128</p>
      </div>
      <div class="card">
        <h3>Online Vouchers</h3>
        <p>45</p>
      </div>
      <div class="card">
        <h3>Total SSIDs</h3>
        <p>6</p>
      </div>
      <div class="card">
        <h3>Bandwidth Usage</h3>
        <p>320GB</p>
      </div>
    </div>

    <!-- Charts -->
    <div class="charts">
      <div class="chart-card">
        <h3>Client Growth</h3>
        <canvas id="lineChart"></canvas>
      </div>
      <div class="chart-card">
        <h3>Network Traffic</h3>
        <canvas id="barChart"></canvas>
      </div>
    </div>

    <div class="footer">
      &copy; 2025 Omada Dashboard Replica | Designed for Fajirz1
    </div>
  </div>

  <script>
    const ctx1 = document.getElementById('lineChart');
    new Chart(ctx1, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Clients',
          data: [100, 120, 140, 180, 160, 200],
          borderColor: '#007cba',
          backgroundColor: 'rgba(0,124,186,0.1)',
          tension: 0.3
        }]
      },
      options: {
        plugins: { legend: { display: false }},
        scales: { y: { beginAtZero: true } }
      }
    });

    const ctx2 = document.getElementById('barChart');
    new Chart(ctx2, {
      type: 'bar',
      data: {
        labels: ['2.4GHz', '5GHz', 'LAN1', 'LAN2'],
        datasets: [{
          label: 'Usage (GB)',
          data: [80, 120, 60, 100],
          backgroundColor: ['#00a8ff', '#9c88ff', '#fbc531', '#4cd137']
        }]
      },
      options: {
        plugins: { legend: { display: false }},
        scales: { y: { beginAtZero: true } }
      }
    });
  </script>

</body>
</html>
