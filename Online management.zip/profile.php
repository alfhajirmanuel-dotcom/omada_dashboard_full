<?php 
session_start(); 
include 'config.php'; 
include 'header.php';

if (!isset($_SESSION['username'])) { 
    header("Location: login.php"); 
    exit;
}

$username = $_SESSION['username']; 
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?"); 
$stmt->bind_param("s", $username); 
$stmt->execute(); 
$result = $stmt->get_result(); 
$user = $result->fetch_assoc(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Omada Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }

       
        /* Main content */
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }

        .profile-card {
            background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 30px;
            max-width: 800px;
            margin: 0 auto;
            color:#fff;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 25px;
            margin-bottom: 25px;
        }

        .profile-header img {
            width: 110px;
            height: 110px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #0077c8;
        }

        .profile-header h3 {
            margin: 0;
            color: #fff;
        }

        .profile-info p {
            font-size: 16px;
            margin: 8px 0;
        }

        .profile-actions a {
            display: inline-block;
            margin-right: 10px;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 6px;
            background-color: #0077c8;
            color: white;
            transition: background-color 0.2s ease;
        }

        .profile-actions a:hover {
            background-color: #005fa3;
        }
        
        .topbar {
            background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
            color: #0591f7;
        }
        @media (max-width: 768px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .main-content, .topbar { margin-left: 0; }
            .profile-card { padding: 20px; }
        }
        /* Sidebar fix */
.sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 230px;
    height: 100%;
    background: #0b3d91;
    color: white;
    display: flex;
    flex-direction: column;
    padding-top: 20px;
    z-index: 1000; /* keeps it above background but below content overlay */
}

/* Make sure main content is beside sidebar */
.main-content {
    margin-left: 230px; /* matches sidebar width */
    padding: 30px;
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    min-height: 100vh;
}


/* Mobile responsive */
@media (max-width: 768px) {
    .sidebar {
        position: fixed;
        top: 0;
        left: -230px;
        width: 230px;
        height: 100%;
        transition: left 0.3s ease;
        z-index: 1001;
    }

    .sidebar.active {
        left: 0;
    }

    .main-content {
        margin-left: 0;
        padding: 20px;
    }

    .topbar {
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 999;
    }

    body {
        padding-top: 60px; /* space for topbar on mobile */
    }
}

    </style>
</head>
<body>

    
    <div class="main-content">
        
        <div class="profile-card">
            <div class="profile-header">
                <?php if (!empty($user['profile_picture'])): ?>
                    <?php if (file_exists("uploads/".$user['profile_picture'])): ?>
                        <img src="uploads/<?php echo $user['profile_picture']; ?>" alt="Profile Picture">
                    <?php else: ?>
                        <img src="image1" alt="Default Profile Picture">
                    <?php endif; ?>
                <?php else: ?>
                    <img src="image1" alt="Default Profile Picture">
                <?php endif; ?>
                <div>
                    <h3><?php echo htmlspecialchars($user['full_name']); ?></h3>
                    <a href="upload_profile_picture.php" class="btn btn-link text-primary">Change Profile Picture</a>
                </div>
            </div>

            <div class="profile-info">
                <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['full_name']); ?></p>
                <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong>Gender:</strong> <?php echo ucfirst(htmlspecialchars($user['gender'])); ?></p>
            </div>

            <div class="profile-actions">
                <a href="edit_profile.php"><i class="fa-solid fa-pen-to-square"></i> Edit Profile</a>
            </div>
        </div>
    </div>

</body>
</html>
