<?php 
include 'config.php'; 
include 'header.php'; 
session_start(); 

if (!isset($_SESSION['username'])) { 
    header("Location: login.php"); 
    exit; 
} 

// 🔹 Get admin user id
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?"); 
$stmt->bind_param("s", $_SESSION['username']); 
$stmt->execute(); 
$result = $stmt->get_result(); 
$user = $result->fetch_assoc(); 
$user_id = $user['id']; 

// 🔹 Delete volunteer application
if (isset($_GET['delete_id'])) { 
    $delete_id = $_GET['delete_id']; 
    $stmt = $conn->prepare("DELETE FROM volunteer_applications WHERE id = ? AND event_id IN (SELECT id FROM events WHERE user_id = ?)"); 
    $stmt->bind_param("ii", $delete_id, $user_id); 
    $stmt->execute(); 
    echo "<script>
        alert('⚠️ Application deleted successfully!');
        window.location.href='view_volunteers.php';
    </script>";
    exit; 
} 

// 🔹 Update status + comment ✅
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $status = $_POST['status'];
    $app_id = $_POST['app_id'];
    $comment = isset($_POST['comment']) ? $_POST['comment'] : ''; // new field

    // ✅ Save both status and comment
    $stmt = $conn->prepare("UPDATE volunteer_applications SET status = ?, comment = ? WHERE id = ?");
    $stmt->bind_param("ssi", $status, $comment, $app_id);
    $stmt->execute();

    // ✅ Normal popup and redirect to same page after OK
    echo "<script>
        alert('✅ Application status updated successfully!');
        window.location.href='view_volunteers.php';
    </script>";
    exit;
}

// 🔹 Fetch volunteer applications (now also get comment)
$stmt = $conn->prepare("
    SELECT va.*, e.title AS event_title, e.date AS event_date
    FROM volunteer_applications va 
    JOIN events e ON va.event_id = e.id 
    WHERE e.user_id = ?
");
$stmt->bind_param("i", $user_id); 
$stmt->execute(); 
$result = $stmt->get_result(); 
$volunteer_applications = $result->fetch_all(MYSQLI_ASSOC); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Volunteers</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
            color: #fff;
        }
        .vol-title {
            color: #fff;
            font-weight: 700;
            margin-bottom: 25px;
            text-shadow: 0 2px 6px rgba(0,0,0,0.2);
        }
        .table th, .table td {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            color: #fff;
            vertical-align: middle;
             max-height: 65vh; /* Adjust height depending on how much you want visible */
  overflow-y: auto;
  padding-right: 8px; /* space for scrollbar */
        }
        .table th {
            background: linear-gradient(90deg, #007bff, #00bfff);
            color: #fff;
        }
        .btn-view {
            background: linear-gradient(90deg, #00bfff, #007bff);
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 8px 14px;
            font-size: 14px;
            transition: 0.3s;
        }
        .btn-view:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 10px rgba(0,123,255,0.3);
        }
        .status-badge {
            padding: 5px 10px;
            border-radius: 8px;
            font-weight: 600;
        }
        .status-badge.Pending { background: #c1940a33; color: #ffd64f; }
        .status-badge.Accepted { background: #0a6b1b33; color: #05f75e; }
        .status-badge.Rejected { background: #5a0a0a33; color: #f55; }
        select {
            background: #2c2742;
            color: #fff;
            border: 1px solid #00bfff;
            border-radius: 6px;
            padding: 5px 8px;
        }
        .btn-update {
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 5px 10px;
            transition: 0.3s;
        }
        .btn-update:hover { background: #0056b3; }
        textarea[name="comment"] {
            width: 100%;
            border-radius: 8px;
            border: 1px solid #007bff;
            padding: 8px;
            resize: none;
        }
        
        html, body {
  height: 100%;
  margin: 0;
  overflow: hidden; /* Prevent full-page scroll */
}

    </style>
</head>
<body>
<div class="container mt-5">
  <h2 class="vol-title">Volunteers Applications</h2>
  <div class="table-responsive shadow-lg rounded">
    <table class="table align-middle table-hover table-borderless">
      <thead>
        <tr>
          <th>Event</th>
          <th>Full Name</th>
          <th>Status</th>
          <th class="text-center">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($volunteer_applications as $vol): ?>
        <tr>
          <td><?php echo htmlspecialchars($vol['event_title']); ?></td>
          <td><?php echo htmlspecialchars($vol['full_name']); ?></td>
          <td><span class="status-badge <?php echo $vol['status']; ?>"><?php echo $vol['status']; ?></span></td>
          <td class="text-center">
            <button type="button" class="btn btn-view" data-toggle="modal" data-target="#viewVolunteerModal<?php echo $vol['id']; ?>">
              Details
            </button>
          </td>
        </tr>

        <!-- Modal -->
        <div class="modal fade" id="viewVolunteerModal<?php echo $vol['id']; ?>" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content border-0 shadow-lg rounded-4">
              <div class="modal-header">
                <h5 class="modal-title fw-semibold">Volunteer Details</h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body text-dark">
                <p><strong>Event:</strong> <?php echo htmlspecialchars($vol['event_title']); ?></p>
                <p><strong>Full Name:</strong> <?php echo htmlspecialchars($vol['full_name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($vol['email']); ?></p>
                <p><strong>Contact:</strong> <?php echo htmlspecialchars($vol['contact_number']); ?></p>
                <p><strong>Age:</strong> <?php echo htmlspecialchars($vol['age']); ?></p>
                <p><strong>Gender:</strong> <?php echo htmlspecialchars($vol['gender']); ?></p>
                <p><strong>Address:</strong> <?php echo htmlspecialchars($vol['address']); ?></p>
                <p><strong>Resume:</strong> 
                  <?php if (!empty($vol['id_upload'])): ?>
                    <a href="uploads/<?php echo htmlspecialchars($vol['id_upload']); ?>" target="_blank" class="resume-link">View File</a>
                  <?php else: ?>
                    <span>No file</span>
                  <?php endif; ?>
                </p>
                <hr>

                <!-- ✅ Status and Comment Form -->
                <form method="post" class="d-flex flex-column" style="gap:10px;">
                  <input type="hidden" name="app_id" value="<?php echo $vol['id']; ?>">

                  <label><strong>Status:</strong></label>
                  <select name="status">
                    <option value="Pending" <?php if ($vol['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                    <option value="Accepted" <?php if ($vol['status'] == 'Accepted') echo 'selected'; ?>>Accepted</option>
                    <option value="Rejected" <?php if ($vol['status'] == 'Rejected') echo 'selected'; ?>>Rejected</option>
                  </select>

                  <label><strong></strong></label>
                  <textarea name="comment" rows="3" placeholder="Write a reason or note..."><?php echo htmlspecialchars($vol['comment'] ?? ''); ?></textarea>

                  <button type="submit" name="update_status" class="btn-update align-self-start">Update</button>
                </form>
              </div>
              <div class="modal-footer">
                <a href="view_volunteers.php?delete_id=<?php echo $vol['id']; ?>" 
                   class="btn btn-danger"
                   onclick="return confirm('⚠️ Are you sure you want to delete this application? This action cannot be undone.');">
                   Delete
                </a>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
