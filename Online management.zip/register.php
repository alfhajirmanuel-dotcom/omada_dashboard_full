<?php
include 'config.php';

$error = '';

if (isset($_POST['register'])) {
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $gender = $_POST['gender'];

    if (empty($full_name) || empty($username) || empty($email) || empty($password) || empty($confirm_password) || empty($gender)) {
        $error = 'Please fill in all fields';
    } elseif ($password != $confirm_password) {
        $error = 'Passwords do not match';
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = 'Username is already taken';
        } else {
            $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, gender) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $full_name, $username, $email, $password, $gender);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                header("Location: login.php");
            } else {
                $error = 'Error registering user';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <style>
body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 🌈 Register Box */
.register-container {
  width: 90%;
  max-width: 420px;
  background: rgba(255, 255, 255, 0.08);
  border-radius: 16px;
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
  padding: 40px 30px 35px;
  text-align: center;
  color: #fff;
  animation: fadeIn 0.6s ease;
}

/* 🪄 Animation */
@keyframes fadeIn {
  from {opacity: 0; transform: translateY(-15px);}
  to {opacity: 1; transform: translateY(0);}
}

/* 🧠 Heading */
h2 {
  font-size: 28px;
  font-weight: 600;
  margin-bottom: 20px;
  color: #00e5ff;
}

/* ⚠️ Error Box */
.error-message {
  background-color: rgba(255, 69, 58, 0.95);
  color: #fff;
  padding: 10px 15px;
  border-radius: 10px;
  margin: 0 auto 18px;
  display: inline-block;
  font-size: 14px;
  box-shadow: 0 0 8px rgba(255, 69, 58, 0.6);
}

/* 🧩 Input Groups */
.input-group {
  position: relative;
  margin-bottom: 22px;
  text-align: left;
}

.input-group label {
  display: block;
  font-size: 14px;
  margin-bottom: 5px;
  color: #eee;
}

.input-group input,
.input-group select {
  width: 86%;
  padding: 10px 45px 10px 12px;
  border-radius: 10px;
  border: none;
  outline: none;
  font-size: 15px;
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
  transition: all 0.3s ease;
}

.input-group input:focus,
.input-group select:focus {
  background: rgba(255,255,255,0.25);
  box-shadow: 0 0 8px #00e5ff;
}

/* 👁️ Icons inside input */
.input-group i {
  position: absolute;
  right: 15px;
  top: 38px;
  color: #ccc;
}

.toggle-password {
  position: absolute;
  right: 35px;
  top: 38px;
  cursor: pointer;
  color: #ccc;
  transition: 0.3s;
}
.toggle-password:hover {
  color: #00e5ff;
}

/* 🚀 Register Button */
button[type="submit"] {
  width: 100%;
  padding: 12px;
  border: none;
  background: linear-gradient(90deg, #00e5ff, #007bff);
  color: #fff;
  font-size: 16px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: 500;
  transition: 0.3s;
  box-shadow: 0 0 12px rgba(0, 229, 255, 0.4);
}

button[type="submit"]:hover {
  background: linear-gradient(90deg, #007bff, #00e5ff);
  transform: scale(1.03);
  box-shadow: 0 0 15px rgba(0, 229, 255, 0.6);
}

/* 🔗 Links */
.register-container p {
  margin-top: 16px;
  font-size: 14px;
}
.register-container p a {
  color: #00e5ff;
  text-decoration: none;
  font-weight: 500;
}
.register-container p a:hover {
  text-decoration: underline;
}

/* 📱 Responsive */
@media (max-width: 480px) {
  .register-container {
    padding: 30px 20px;
  }
  h2 {
    font-size: 22px;
  }
  .error-message {
    font-size: 13px;
  }
}

#gender{
    background-color:grey;
    color:white;
}
  </style>
</head>
<body>
  <div class="register-container">
    <form action="" method="post">
      <h2>Register</h2>
      <?php if (!empty($error)) : ?>
        <div class="error-message"><?= $error; ?></div>
      <?php endif; ?>

      <div class="input-group">
        <label for="full_name">Full Name</label>
        <input type="text" id="full_name" name="full_name" required>
        <i class="fa fa-user"></i>
      </div>

      <div class="input-group">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" required>
        <i class="fa fa-id-badge"></i>
      </div>

      <div class="input-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
        <i class="fa fa-envelope"></i>
      </div>

      <div class="input-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
        <i class="fa fa-lock"></i>
        <i class="fa fa-eye toggle-password" onclick="togglePassword('password', this)"></i>
      </div>

      <div class="input-group">
        <label for="confirm_password">Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password" required>
        <i class="fa fa-lock"></i>
        <i class="fa fa-eye toggle-password" onclick="togglePassword('confirm_password', this)"></i>
      </div>

      <div class="input-group">
        <label for="gender">Gender</label>
        <select id="gender" name="gender" required>
          <option value="">Select Gender</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
        <i class="fa fa-venus-mars"></i>
      </div>

      <button type="submit" name="register">Register</button>
      <p>Already have an account? <a href="login.php">Login</a></p>
    </form>
  </div>

  <script>
  function togglePassword(id, el) {
    const input = document.getElementById(id);
    if (input.type === "password") {
      input.type = "text";
      el.classList.remove("fa-eye");
      el.classList.add("fa-eye-slash");
    } else {
      input.type = "password";
      el.classList.remove("fa-eye-slash");
      el.classList.add("fa-eye");
    }
  }
  </script>
</body>
</html>
