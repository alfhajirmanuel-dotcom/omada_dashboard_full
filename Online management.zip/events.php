<?php 
include 'config.php'; 
include 'header.php';
session_start(); 
if (!isset($_SESSION['username'])) { 
    header("Location: login.php"); 
    
}

$stmt = $conn->prepare("SELECT id, profile_picture FROM users WHERE username = ?"); 
$stmt->bind_param("s", $_SESSION['username']); 
$stmt->execute(); 
$result = $stmt->get_result(); 
$user = $result->fetch_assoc(); 
$user_id = $user['id'];

$search_query = '';
if (isset($_GET['s'])) {
    $search_query = $_GET['s'];
    $stmt = $conn->prepare("SELECT events.*, users.full_name FROM events JOIN users ON events.user_id = users.id WHERE events.title LIKE ? OR events.description LIKE ?");
    $search_param = '%' . $search_query . '%';
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt = $conn->prepare("SELECT events.*, users.full_name, users.profile_picture, users.username FROM events JOIN users ON events.user_id = users.id WHERE events.title LIKE ? OR events.description LIKE ?");
} else {
    $stmt = $conn->prepare("SELECT events.*, users.full_name FROM events JOIN users ON events.user_id = users.id");
}
if (isset($_GET['s'])) { 
  $search_query = $_GET['s']; 
  $stmt = $conn->prepare("SELECT events.*, users.profile_picture, users.full_name, users.username FROM events JOIN users ON events.user_id = users.id WHERE events.title LIKE ? OR events.description LIKE ?"); 
  $search_param = '%' . $search_query . '%'; 
  $stmt->bind_param("ss", $search_param, $search_param); 
} else { 
  $stmt = $conn->prepare("SELECT events.*, users.profile_picture, users.full_name, users.username FROM events JOIN users ON events.user_id = users.id"); 
}


$stmt->execute(); 
$result = $stmt->get_result(); 
$events_with_user = $result->fetch_all(MYSQLI_ASSOC);

if (isset($_POST['delete'])) { 
    $event_id = $_POST['event_id']; 
    $stmt = $conn->prepare("DELETE FROM events WHERE id = ?"); 
    $stmt->bind_param("i", $event_id); 
    $stmt->execute(); 
    header("Location: events.php"); 
} 

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Events </title>

  <!-- keep any external libs you used -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

  <!-- Omada-style UI (only CSS/layout changes) -->
 <style>
:root {
  --omada-bg: #f5f7fa;
  --panel: #ffffff;
  --sidebar: #1c2533;
  --accent: #00aaff;
  --muted: #6b7280;
  --radius: 12px;
}

html, body {
  height: 107%;
  margin: 0;
  font-family: "Poppins", "Segoe UI", Inter, Roboto, Arial, sans-serif;
   background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  color: #222;
}



.omada-logo {
  font-weight: 700;
  font-size: 18px;
  color: var(--accent);
  text-align: center;
  margin-bottom: 16px;
}

.topbar{
 background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
 color: #0591f7;
}

.top-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.top-title {
  font-size: 20px;
  font-weight: 600;
  color: #0591f7;
}

.top-search input {
  width: 340px;
  max-width: 50vw;
  padding: 10px 14px;
  border-radius: 10px;
  border: 1px solid #e2e8f0;
  font-size: 14px;
  transition: all 0.3s;
   background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
}

.top-search input:focus {
  outline: none;
  border-color: var(--accent);
  box-shadow: 0 0 6px rgba(0, 170, 255, 0.3);
}
.btn-search {
  background: linear-gradient(90deg, #007bff, #00c6ff);
  border: none;
  color: #fff;
  padding: 10px 18px;
  border-radius: 8px;
  font-size: 15px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 3px 6px rgba(0, 123, 255, 0.3);
}

.btn-search:hover {
  background: linear-gradient(90deg, #0056b3, #00a6ff);
  transform: translateY(-2px);
  box-shadow: 0 6px 10px rgba(0, 123, 255, 0.4);
}

.btn-search:active {
  transform: translateY(0);
  box-shadow: 0 2px 4px rgba(0, 123, 255, 0.3);
}

.btn-search:focus {
  outline: none;
  box-shadow: 0 0 0 3px rgba(0, 150, 255, 0.4);
}
/* Make visible and full width on mobile */
@media (max-width: 768px) {
  .top-search input {
    display: block !important;
  }

  .search-box {
    width: 100%;
    margin-top: 10px;
  }

  .top-search {
    width: 100%;
  }
}
/* Inline search bar styling */
.search-box {
  position: relative;
  display: flex;
  align-items: center;
  width: 340px;
  max-width: 100%;
  margin: 0 auto; /* centers on larger screens too */
}

.search-box input[type="search"] {
  width: 100%;
  padding: 10px 44px 10px 14px;
  border-radius: 30px;
  border: 1px solid #e2e8f0;
  font-size: 14px;
  transition: all 0.3s;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  color: #fff;
}

.search-box input::placeholder {
  color: #ccc;
}

.search-box input:focus {
  outline: none;
  border-color: var(--accent);
  box-shadow: 0 0 6px rgba(0, 170, 255, 0.3);
}

.search-box .btn-search {
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  background: linear-gradient(90deg, #007bff, #00c6ff);
  border: none;
  color: #fff;
  padding: 6px 10px;
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 14px;
  line-height: 1;
}

.search-box .btn-search:hover {
  background: linear-gradient(90deg, #0056b3, #00a6ff);
  transform: translateY(-50%) scale(1.05);
}

.user-pill {
  display: flex;
  gap: 10px;
  align-items: center;
  padding: 6px 10px;
  border-radius: var(--radius);
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  border: 1px solid #e0e7ef;
  color:#0591f7;
  width: 130px;
}

.user-pill img {
  width: 50px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--accent);
}

/* Content */
.omada-content {
  padding: 24px;
  overflow-y: auto;
}

.panel {
  background: var(--panel);
  border-radius: var(--radius);
  padding: 20px;
  box-shadow: 0 4px 18px rgba(13, 27, 40, 0.05);
  margin-bottom: 20px;
}

/* Buttons */
.btn-create {
  background: var(--accent);
  color: #fff;
  border: none;
  padding: 10px 18px;
  border-radius: var(--radius);
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-create:hover {
  background: #0094dd;
  transform: scale(1.03);
}

/* Event list */
.event-list {
  list-style: none;
  padding: 0;
  margin: 0;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 18px;
   background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
}

.event-item {
   background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  border-radius: var(--radius);
  padding: 16px;
  box-shadow: 0 4px 14px rgba(0,0,0,0.05);
  transition: transform 0.2s, box-shadow 0.2s;
}

.event-item:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 25px rgba(0,0,0,0.08);
}

.event-meta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 10px;
}

.event-meta img {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  border: 2px solid var(--accent);
  object-fit: cover;
}

.event-meta .who {
  font-weight: 600;
  color:#fff;
}

.event-meta .when {
  color: var(--muted);
  font-size: 13px;
}

.event-body h3 {
  font-size: 18px;
  margin-bottom: 8px;
  color: #fff;
}

.event-body p {
  margin: 6px 0;
  color: #fff;
  line-height: 1.5;
  
}

.event-body img {
  width: 100%;
  border-radius: var(--radius);
  margin-top: 10px;
  cursor: pointer;
  transition: transform 0.2s;
}

.event-body img:hover {
  transform: scale(1.02);
}

.event-actions {
  margin-top: 12px;
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
/* Make event list scrollable if too long */
.event-list {
  max-height: 65vh; /* Adjust height depending on how much you want visible */
  overflow-y: auto;
  padding-right: 8px; /* space for scrollbar */
}

/* Optional: nice scrollbar styling */
.event-list::-webkit-scrollbar {
  width: 8px;
}

.event-list::-webkit-scrollbar-thumb {
  background-color: rgba(255, 255, 255, 0.3);
  border-radius: 6px;
}

.event-list::-webkit-scrollbar-thumb:hover {
  background-color: rgba(255, 255, 255, 0.5);
}

.event-list::-webkit-scrollbar-track {
  background: transparent;
}

.panel{
 background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);   
}

 
.btn-apply, .btn-delete {
  border: none;
  border-radius: var(--radius);
  cursor: pointer;
  font-weight: 500;
  padding: 8px 12px;
  transition: all 0.3s ease;
}

.btn-apply {
  border: 1px solid var(--accent);
  color: var(--accent);
  background: transparent;
}

.btn-apply:hover {
  background: var(--accent);
  color: #fff;
}

.btn-delete {
  background: #e53935;
  color: #fff;
}

.btn-delete:hover {
  background: #d32f2f;
}

/* Responsive */
@media (max-width: 1024px) {
  .omada-sidebar {
    width: 80px;
  }
  .omada-nav a span {
    display: none;
  }
  .omada-main {
    margin-left: 80px;
  }
  .top-search input {
    width: 220px;
  }
}

@media (max-width: 768px) {
  .omada-sidebar {
    display: none;
  }
  .omada-main {
    margin-left: 0;
  }
  .top-search input {
    display: none;
  }
  .omada-topbar {
    flex-wrap: wrap;
    height: auto;
    gap: 8px;
    padding: 10px 16px;
  }
  .event-list {
    grid-template-columns: 1fr;
  }
 
.user-pill {
    display: flex;
    gap: 10px;
    align-items: center;
    padding: 6px 10px;
    border-radius: var(--radius);
    border: 1px solid #e0e7ef;
}

@media (max-width: 480px) {
  .btn-create {
    width: 100%;
    text-align: center;
  }
  .top-title {
    font-size: 16px;
  }
  .event-meta img {
    width: 40px;
    height: 40px;
  }
}
html, body {
  height: 100%;
  margin: 0;
  overflow: hidden; /* Prevent full-page scroll */
}

.omada-main {
  display: flex;
  flex-direction: column;
  height: 100vh;
  overflow: hidden; /* Keeps internal control of scroll area */
}

.omada-content {
  flex: 1;
  overflow-y: auto; /* Enables scrolling inside content area */
  overflow-x: hidden;
  scroll-behavior: smooth;
}

/* Optional: nice custom scrollbar */
.omada-content::-webkit-scrollbar {
  width: 8px;
}
.omada-content::-webkit-scrollbar-thumb {
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 4px;
}
.omada-content::-webkit-scrollbar-thumb:hover {
  background-color: rgba(0, 0, 0, 0.35);
}
.omada-content::-webkit-scrollbar-track {
  background-color: transparent;
}


</style>

</head>
<body>

<div class="omada-shell">



  <!-- MAIN -->
  <main class="omada-main">

    <!-- TOPBAR -->
    <header class="omada-topbar">
      <div class="top-left">
        <div class="top-title">Events Feed</div>
        <div class="top-search" style="margin-left:14px;">
         <form method="get" action="" class="search-form">
         <div class="search-box">
           <input type="search" name="s" placeholder="Search events..." value="<?php echo htmlspecialchars($search_query); ?>" />
           <button type="submit" class="btn-search">🔍</button>
         </div>
       </form>

        </div>
      </div>

      <div class="top-actions">
        <div class="user-pill">
          <img src="<?php echo file_exists('uploads/'.($user['profile_picture'] ?? '')) ? 'uploads/'.htmlspecialchars($user['profile_picture']) : 'default-profile-picture.jpg'; ?>" alt="user">
          <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
        </div style="background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);">
      </div>
    </header>

    <!-- CONTENT -->
    <section class="omada-content">

      <div class="panel">
        <div class="create-row">
          <div class="left">
            <!-- CREATE BUTTON: exact trigger preserved -->
            <button type="button" class="btn-create" data-toggle="modal" data-target="#createEventModal">Create Event | Activity</button>
          </div>

          <div class="right">
            <!-- optional quick info -->
            <small style="color:var(--muted)">Manage community events  create, apply, accept volunteers</small>
          </div>
        </div>

        <!-- Keep your original modal EXACTLY as you provided (no changes to markup or names) -->
        <!-- Modal -->
        <div class="modal fade" id="createEventModal" tabindex="-1" role="dialog" aria-labelledby="createEventModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="createEventModalLabel">Create Event</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form action="create_event.php" method="post" enctype="multipart/form-data">
                  <label for="title"></label>
                  <input type="text" id="title" name="title" placeholder="Title" class="form-control">
                  <label for="description"></label>
                  <textarea id="description" name="description" placeholder="Description" class="form-control"></textarea>
                  <label for="date">Date:</label>
                  <input type="date" id="date" name="date" class="form-control">
                  <label for="time">Time:</label>
                  <input type="time" id="time" name="time" class="form-control">
                  <label for="image">Image:</label>
                  <input type="file" id="image" name="image" class="form-control-file"><br>
                  <button type="submit" class="btn btn-primary">Create Event</button >
                </form>

              </div>
            </div>
          </div>
        </div>
        <!-- END modal (unchanged) -->

        <!-- EVENTS LIST: keep your PHP logic & markup intact, only wrapped in Omada styling -->
        <ul class="event-list" aria-live="polite">
          <?php 
          // Sort events by id in descending order to show new posts on top
          usort($events_with_user, function($a, $b) {
            return $b['id'] <=> $a['id'];
          });

          foreach ($events_with_user as $event): ?>
            <li class="event-item">
              <div class="event-meta">
                <img src="<?php echo !empty($event['profile_picture']) && file_exists('uploads/'.$event['profile_picture']) ? 'uploads/'.$event['profile_picture'] : 'default-profile-picture.jpg'; ?>" alt="profile">
                <div>
                  <div class="who"><?php echo htmlspecialchars($event['full_name']); ?></div>
                  <div class="when"><?php echo htmlspecialchars($event['date']); ?>  <?php echo htmlspecialchars($event['time']); ?></div>
                </div>
              </div>

              <div class="event-body">
                <h3 style="margin:0 0 8px;"><?php echo htmlspecialchars($event['title']); ?></h3>
                <p><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>

                <?php if (file_exists('uploads/' . $event['image'])): ?>
                  <img src="uploads/<?php echo $event['image']; ?>" alt="Event Image" onclick="viewImage(this.src)">
                <?php else: ?>
                  <p style="color:var(--muted)">Image not found.</p>
                <?php endif; ?>
              </div>

              <div class="event-actions">
                <?php if ($event['user_id'] == $user_id): ?>
                  <!-- user is owner: keep original delete form exactly (though styled) -->
                  <form action="delete_event.php" method="post" style="display:inline;">
                    <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                    <button type="submit" name="delete" class="btn-delete">Delete</button>
                  </form>

                  <?php 
                  $stmt_volunteers = $conn->prepare("SELECT volunteers.*, users.full_name FROM volunteers JOIN users ON volunteers.user_id = users.id WHERE event_id = ?"); 
                  $stmt_volunteers->bind_param("i", $event['id']); 
                  $stmt_volunteers->execute(); 
                  $result_volunteers = $stmt_volunteers->get_result(); 
                  $volunteers = $result_volunteers->fetch_all(MYSQLI_ASSOC); 
                  foreach ($volunteers as $volunteer): ?>
                    <div style="margin-left:12px;">
                      <small>Volunteer: <?php echo htmlspecialchars($volunteer['full_name']); ?> â€” Status: <?php echo htmlspecialchars($volunteer['status']); ?></small>
                      <?php if ($volunteer['status'] == 'pending'): ?>
                        <div style="margin-top:6px;">
                          <form action="accept_reject_volunteer.php" method="post" style="display:inline;">
                            <input type="hidden" name="volunteer_id" value="<?php echo $volunteer['id']; ?>">
                            <button hidden id="brv" type="submit" name="accept_volunteer" class="btn-apply">Accept</button>
                            <button hidden id="brv" type="submit" name="reject_volunteer" class="btn-apply" style="border-color:#e5533c; color:#e5533c;">Reject</button>
                          </form>
                        </div>
                      <?php endif; ?>
                    </div>
                  <?php endforeach; ?>

                <?php else: ?>
                  <?php 
                  $stmt_volunteer_status = $conn->prepare("SELECT status FROM volunteers WHERE event_id = ? AND user_id = ?"); 
                  $stmt_volunteer_status->bind_param("ii", $event['id'], $user_id); 
                  $stmt_volunteer_status->execute(); 
                  $result_volunteer_status = $stmt_volunteer_status->get_result(); 
                  $volunteer_status = $result_volunteer_status->fetch_assoc(); 
                  if ($volunteer_status) { 
                    if ($volunteer_status['status'] == 'pending') { 
                      echo "<p class='status-text' style='color:#C1940A;'>Application submitted successfully</p>"; 
                    } elseif ($volunteer_status['status'] == 'accepted') { 
                      echo "<p class='status-text' style='color:#06C91D;'>Application accepted</p>"; 
                    } elseif ($volunteer_status['status'] == 'rejected') { 
                      echo "<p class='status-text' style='color:#FC0C0C;'>Application rejected</p>";
                      echo "<p style='color:red;'>Note: Your application has been rejected due to a mismatch between your resume and the information provided in your application</p>"; 
                    } 
                  } else { ?>
                    <form action="apply_volunteer.php" method="post" style="display:inline;">
                      <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                      <button type="submit" name="apply_volunteer" class="btn-apply">Apply as Volunteer</button>
                    </form>
                  <?php } ?>
                <?php endif; ?>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>

      </div> <!-- panel -->
    </section> <!-- omada-content -->

  </main>
</div>

<!-- Keep your original scripts & Bootstrap -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- keep your original JS but scoped here -->
<script>
  // Confirm deletion - keep exact behavior
  const deleteButtons = document.querySelectorAll('form[action="delete_event.php"] button[name="delete"], button[name="delete"]');
  deleteButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      if (!confirm('Are you sure you want to delete this event?')) {
        e.preventDefault();
      }
    });
  });

  // Confirm apply volunteer - keep exact behavior
  const applyVolunteerButtons = document.querySelectorAll('button[name="apply_volunteer"]');
  applyVolunteerButtons.forEach(button => {
      button.addEventListener('click', () => {
          if (confirm('Are you sure you want to apply as a volunteer for this event?')) {
              // form will submit naturally
          } else {
              // prevent the form submission if user cancels (the button is inside a form)
              event.preventDefault?.();
          }
      });
  });

  // image preview modal (keeps your behavior)
  function viewImage(src) {
    const modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.background = 'rgba(0, 0, 0, 0.7)';
    modal.style.display = 'flex';
    modal.style.justifyContent = 'center';
    modal.style.alignItems = 'center';
    modal.style.zIndex = 9999;

    const image = document.createElement('img');
    image.src = src;
    image.style.maxWidth = '90%';
    image.style.maxHeight = '90%';
    image.style.borderRadius = '8px';
    image.style.boxShadow = '0 8px 30px rgba(0,0,0,0.5)';

    modal.appendChild(image);
    document.body.appendChild(modal);

    modal.addEventListener('click', () => {
      modal.remove();
    });
  }
</script>
</body>
</html>
