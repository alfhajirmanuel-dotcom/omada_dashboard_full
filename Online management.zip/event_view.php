<?php
session_start();
include 'config.php';
include 'header.php';

if (!isset($_SESSION['username'])) {
  header("Location: login.php");
  exit;
}

// Get current user info
$stmt_user = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt_user->bind_param("s", $_SESSION['username']);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user = $result_user->fetch_assoc();
$user_id = $user['id'];

// Ensure event id exists
if (!isset($_GET['id'])) {
  die("<p style='color:red; text-align:center;'>No event selected.</p>");
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM events WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  die("<p style='color:red; text-align:center;'>Event not found.</p>");
}

$event = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($event['title']) ?> | Event Details</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  color: #fff;
  display: flex;
}

/* --- Sidebar fixed (stable) --- */
.sidebar {
  position: fixed;
  top: 0;
  left: 0;
  width: 250px;
  height: 100vh;
  background-color: #0b3d91;
  color: #fff;
  padding-top: 20px;
  box-shadow: 3px 0 10px rgba(0, 0, 0, 0.2);
  z-index: 10;
  overflow-y: auto;
}

.main-content {
  flex: 1;
  margin-left: 250px;
  padding: 30px;
  box-sizing: border-box;
  min-height: 100vh;
  overflow-x: hidden;
}

.event-view-container {
  width: 100%;
  max-width: 900px;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 5px 20px rgba(0,0,0,0.08);
  margin: 0 auto;
}

.event-image {
  width: 100%;
  height: 350px;
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 25px;
  background: #f1f3f6;
  display: flex;
  align-items: center;
  justify-content: center;
}
.event-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 12px;
}

.event-title {
  font-size: 26px;
  font-weight: 700;
  color: #00e5ff;
  margin-bottom: 10px;
}
.event-date {
  color: #ccc;
  font-size: 14px;
  margin-bottom: 20px;
}
.event-description {
  font-size: 15px;
  color: #fff;
  line-height: 1.6;
  white-space: pre-line;
  background: rgba(255,255,255,0.05);
  padding: 15px;
  border-radius: 10px;
  border: 1px solid #333;
}

.back-btn {
  display: inline-block;
  margin-top: 25px;
  background: linear-gradient(90deg, #00e5ff, #007bff);
  color: #fff;
  padding: 10px 18px;
  border-radius: 10px;
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}
.back-btn:hover {
  background: linear-gradient(90deg, #007bff, #00e5ff);
  transform: scale(1.03);
}

.btn-apply {
  border: 1px solid #00baff;
  background: transparent;
  color: #00baff;
  border-radius: 10px;
  padding: 10px 20px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
}
.btn-apply:hover {
  background: #00baff;
  color: #fff;
}

.status-text {
  margin-top: 12px;
  font-size: 15px;
  font-weight: 500;
}

@media (max-width: 768px) {
  body {
    flex-direction: column;
  }
  .sidebar {
    position: fixed;
    width: 200px;
    height: 100%;
    left: 0;
    top: 0;
    transform: translateX(-200px);
    transition: transform 0.3s ease-in-out;
  }
  .sidebar.active {
    transform: translateX(0);
  }
  .main-content {
    margin-left: 0;
    padding: 20px;
  }
  .menu-toggle {
    position: fixed;
    top: 15px;
    left: 15px;
    background: #007bff;
    color: #fff;
    border: none;
    padding: 10px;
    border-radius: 6px;
    z-index: 20;
  }
  .event-view-container {
    padding: 20px;
  }
  .event-title {
    font-size: 22px;
  }
  .event-image {
    height: 220px;
  }
}
</style>
</head>
<body>

<button class="menu-toggle" onclick="toggleSidebar()">☰</button>

<div class="main-content">
  <h2 style="margin-bottom:25px; font-weight:600; color:#00e5ff;">Event Details</h2>

  <div class="event-view-container">
    <?php if (!empty($event['image'])): ?>
      <div class="event-image">
        <img src="uploads/<?= htmlspecialchars($event['image']) ?>" alt="Event Image">
      </div>
    <?php else: ?>
      <div class="event-image">No Image Available</div>
    <?php endif; ?>

    <div class="event-title"><?= htmlspecialchars($event['title']) ?></div>
    <div class="event-date">📅 <?= htmlspecialchars($event['date']) ?></div>
    <div class="event-description"><?= nl2br(htmlspecialchars($event['description'])) ?></div>

    <!-- Volunteer Application Logic -->
    <div class="event-actions" style="margin-top:20px;">
      <?php
      if ($event['user_id'] == $user_id) {
        echo "<p class='status-text' style='color:#aaa;'>You are the owner of this event.</p>";

        // Show volunteers list for owner
        $stmt_vols = $conn->prepare("SELECT volunteers.*, users.full_name FROM volunteers JOIN users ON volunteers.user_id = users.id WHERE event_id = ?");
        $stmt_vols->bind_param("i", $event['id']);
        $stmt_vols->execute();
        $res_vols = $stmt_vols->get_result();
        while ($vol = $res_vols->fetch_assoc()) {
          echo "<div style='margin-top:10px;'>
                  <small>Volunteer: ".htmlspecialchars($vol['full_name'])." — Status: ".htmlspecialchars($vol['status'])."</small>";
          if ($vol['status'] == 'pending') {
            echo "<form action='accept_reject_volunteer.php' method='post' style='margin-top:6px;'>
                    <input type='hidden' name='volunteer_id' value='".intval($vol['id'])."'>
                    <button type='submit' name='accept_volunteer' class='btn-apply'>Accept</button>
                    <button type='submit' name='reject_volunteer' class='btn-apply' style='border-color:#e5533c;color:#e5533c;'>Reject</button>
                  </form>";
          }
          echo "</div>";
        }

      } else {
        // Check volunteer status
        $stmt_check = $conn->prepare("SELECT status FROM volunteers WHERE event_id = ? AND user_id = ?");
        $stmt_check->bind_param("ii", $event['id'], $user_id);
        $stmt_check->execute();
        $res_check = $stmt_check->get_result();
        $status = $res_check->fetch_assoc();

        if ($status) {
          if ($status['status'] == 'pending') {
            echo "<p class='status-text' style='color:#C1940A;'>Application pending</p>";
          } elseif ($status['status'] == 'accepted') {
            echo "<p class='status-text' style='color:#06C91D;'>Application accepted</p>";
          } elseif ($status['status'] == 'rejected') {
            echo "<p class='status-text' style='color:#FC0C0C;'>Application rejected</p>";
            echo "<p style='color:red;'>Note: Your application was rejected due to mismatched information or resume.</p>";
          }
        } else {
          echo "<form action='apply_volunteer.php' method='post'>
                  <input type='hidden' name='event_id' value='".intval($event['id'])."'>
                  <button type='submit' name='apply_volunteer' class='btn-apply'>Apply as Volunteer</button>
                </form>";
        }
      }
      ?>
    </div>

    <a href="events_list.php" class="back-btn">← Back to Events</a>
  </div>
</div>

<script>
function toggleSidebar() {
  document.getElementById('sidebar')?.classList.toggle('active');
}
</script>
</body>
</html>
