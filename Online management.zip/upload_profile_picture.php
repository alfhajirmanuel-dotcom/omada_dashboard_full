<?php 
session_start(); 
include 'config.php'; 
include 'header.php'; 
if (!isset($_SESSION['username'])) { 
  header("Location: login.php"); 
} 
$username = $_SESSION['username']; 

if (isset($_POST['upload'])) { 
  $file = $_FILES['profile_picture']; 
  $fileName = $file['name']; 
  $fileTmpName = $file['tmp_name']; 
  $fileSize = $file['size']; 
  $fileError = $file['error']; 
  $fileType = $file['type']; 

  $fileExt = explode('.', $fileName); 
  $fileActualExt = strtolower(end($fileExt)); 
  $allowed = array('jpg', 'jpeg', 'png'); 

  if (in_array($fileActualExt, $allowed)) { 
    if ($fileError === 0) { 
      if ($fileSize < 1000000) { 
        $fileNameNew = uniqid('', true).".".$fileActualExt; 
        $fileDestination = 'uploads/'.$fileNameNew; 

        if (move_uploaded_file($fileTmpName, $fileDestination)) { 
          $stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE username = ?"); 
          $stmt->bind_param("ss", $fileNameNew, $username); 
          if ($stmt->execute()) { 
            header("Location: profile.php"); 
            exit(); 
          } else { 
            echo "Error updating database: " . $conn->error; 
          } 
        } else { 
          echo "Error uploading file!"; 
        } 
      } else { 
        echo "Your file is too big!"; 
      } 
    } else { 
      echo "There was an error uploading your file!"; 
    } 
  } else { 
    echo "You cannot upload files of this type!"; 
  } 
} 
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Profile Picture</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="upload-profile-picture-container">
        <h2>Upload Profile Picture</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="profile_picture">
            <button type="submit" name="upload">Upload</button>
        </form>
    </div>
</body>
</html>

<style type="text/css">
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
}
  .topbar {
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    color: #0591f7;
}
.profile-container {
    width: 80%;
    margin: 40px auto;
    padding: 20px;
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    border: 1px solid #ddd;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.profile-picture {
    text-align: center;
    margin-bottom: 20px;
}

.profile-picture img {
    border-radius: 50%;
    width: 100px;
    height: 100px;
    object-fit: cover;
}

.profile-info {
    margin-bottom: 20px;
}

.profile-info p {
    margin-bottom: 10px;
}

.profile-actions {
    margin-top: 20px;
}

.profile-actions a {
    text-decoration: none;
    color: #337ab7;
    margin-right: 10px;
}

.upload-profile-picture-container {
    width: 80%;
    margin: 40px auto;
    padding: 20px;
    border: 1px solid #e0e7ef;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    color:#e0e7ef;
}

.upload-profile-picture-container form {
    margin-top: 20px;
}

.upload-profile-picture-container input[type="file"] {
    padding: 10px;
    border: none;
    border-radius: 5px;
    background-color: #f0f0f0;
}

.upload-profile-picture-container button[type="submit"] {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    background-color: #337ab7;
    color: #fff;
    cursor: pointer;
}

</style>