<?php
session_start();
include 'config.php';

if (!isset($_SESSION['username']) || !isset($_POST['volunteer_id'])) {
    header("Location: dashboard.php");
    exit;
}

$volunteer_id = intval($_POST['volunteer_id']);

// Verify the application belongs to this user
$stmt_user = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt_user->bind_param("s", $_SESSION['username']);
$stmt_user->execute();
$user = $stmt_user->get_result()->fetch_assoc();

$stmt_check = $conn->prepare("SELECT * FROM volunteers WHERE id = ? AND user_id = ?");
$stmt_check->bind_param("ii", $volunteer_id, $user['id']);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    $stmt_delete = $conn->prepare("DELETE FROM volunteers WHERE id = ?");
    $stmt_delete->bind_param("i", $volunteer_id);
    $stmt_delete->execute();
}

header("Location: dashboard.php");
exit;
?>
