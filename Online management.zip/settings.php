<?php session_start();
if (!isset($_SESSION['username'])) { 
    header("Location: login.php");
   
}
 include 'header.php'; 
?>
<div class="settings-container">
  <h2>Account Settings</h2>
  <div class="settings-links">
    <ul>
      
      <li><a href="change_password.php"><i class="fa-solid fa-lock"></i> Change Password</a></li>
      <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
    </ul>
  </div>
</div>

<style>
body {
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
}
.settings-container {
  max-width: 400px;
  margin: 40px auto;
  padding: 20px;
  background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
  border: 1px solid #0591f7;
  border-radius: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  color:#fff;
}

.settings-container h2 {
  margin-top: 0;
  color: #0591f7;
}

.settings-links ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.settings-links li {
  margin-bottom: 10px;
  padding: 10px;
  border-bottom: 1px solid #ccc;
}

.settings-links li:last-child {
  border-bottom: none;
}

.settings-links a {
  text-decoration: none;
  color: #337ab7;
  transition: color 0.3s ease-in-out;
}

.settings-links a:hover {
  color: #23527c;
}

.settings-links i {
  margin-right: 10px;
}
 .topbar {
    background: radial-gradient(circle at top left, #1f1c2c, #2c2742, #3a3058);
    color: #0591f7;
}
</style>